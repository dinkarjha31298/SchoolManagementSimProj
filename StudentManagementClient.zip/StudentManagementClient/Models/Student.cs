﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagementClient.Models
{
    public class Student
    {
        [Key]
        [Display(Name = "Student Name")]
        public string Stname { get; set; }
        [Display(Name = "Student ID")]
        public int Stid { get; set; }
        
        [Display(Name = "Student Age")]
        public int Stage { get; set; }
        [Display(Name = "Student Class")]
        public int Stclas { get; set; }
        
    }
}
