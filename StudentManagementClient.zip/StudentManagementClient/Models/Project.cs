﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagementClient.Models
{
    public class Project
    {
        [Key]
        [Display(Name = "Project Name")]
        public string Prname { get; set; }
        [Display(Name = "Project ID")]
        public int Prid { get; set; }
       
        [Display(Name = "Student ID")]
        public int StId { get; set; }
        
    }
}
