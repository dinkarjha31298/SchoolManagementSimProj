﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using StudentManagementClient.Models;
using System.Text;
using Newtonsoft.Json;

namespace StudentManagementClient.Controllers
{
    public class StudentsController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44325/api");   //Port No.
        HttpClient client;

        public StudentsController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;

        }

        public IActionResult GetDetails()
        {
            List<Student> ls = new List<Student>();

            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Students").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                ls = JsonConvert.DeserializeObject<List<Student>>(data);
            }
            return View(ls);
        }
        public IActionResult Details(int id)
        {
            Student emp = new Student();

            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Students/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                emp = JsonConvert.DeserializeObject<Student>(data);
            }

            return View(emp);
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Student emp)
        {
            string data = JsonConvert.SerializeObject(emp);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");

            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/Students/", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("GetDetails");
            }
            return BadRequest();

        }

        public ActionResult Edit(int id)
        {
            Student emp = new Student();
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Students/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                emp = JsonConvert.DeserializeObject<Student>(data);
            }
            return View(emp);
        }
        [HttpPost]
        public ActionResult Edit(Student emp)
        {
            string data = JsonConvert.SerializeObject(emp);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");

            HttpResponseMessage response = client.PutAsync(client.BaseAddress + "/Students/" + emp.Stid, content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("GetDetails");
            return BadRequest();
        }

        public ActionResult Delete(int id)
        {
            HttpResponseMessage response = client.DeleteAsync(client.BaseAddress + "/Students/" + id).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("GetDetails");
            return BadRequest();
        }
    }
}
