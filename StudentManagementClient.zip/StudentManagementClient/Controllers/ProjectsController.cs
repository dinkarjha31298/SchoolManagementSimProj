﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using StudentManagementClient.Models;
using Newtonsoft.Json;

namespace StudentManagementClient.Controllers
{
    public class ProjectsController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44325/api");   //Port No.
        HttpClient client;

        public ProjectsController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;

        }

        public IActionResult GetDetails()
        {
            List<Project> ls = new List<Project>();

            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Projects").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                ls = JsonConvert.DeserializeObject<List<Project>>(data);
            }
            return View(ls);
        }
        public IActionResult Details(int id)
        {
            Project emp = new Project();

            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Projects/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                emp = JsonConvert.DeserializeObject<Project>(data);
            }

            return View(emp);
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Project emp)
        {
            string data = JsonConvert.SerializeObject(emp);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");

            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/Projects/", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("GetDetails");
            }
            return BadRequest();

        }

        public ActionResult Edit(int id)
        {
            Project emp = new Project();
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Projects/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                emp = JsonConvert.DeserializeObject<Project>(data);
            }
            return View(emp);
        }
        [HttpPost]
        public ActionResult Edit(Project emp)
        {
            string data = JsonConvert.SerializeObject(emp);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");

            HttpResponseMessage response = client.PutAsync(client.BaseAddress + "/Projects/" + emp.Prid, content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("GetDetails");
            return BadRequest();
        }

        public ActionResult Delete(int id)
        {
            HttpResponseMessage response = client.DeleteAsync(client.BaseAddress + "/Projects/" + id).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("GetDetails");
            return BadRequest();
        }
    }
}
