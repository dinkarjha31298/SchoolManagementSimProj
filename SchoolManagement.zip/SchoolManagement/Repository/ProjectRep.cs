﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagement.Repository
{
    
        public class ProjectRep : IProjectRep
        {
            studentsysContext db;
            public ProjectRep(studentsysContext _db)
            {
                db = _db;
            }

            public List<Project> GetDetails()
            {
                return db.Project.ToList();
            }

            public Project GetDetail(int id)
            {
                if (db != null)
                {
                    return (db.Project.Where(x => x.Prid == id)).FirstOrDefault();
                }
                return null;
            }

            public int AddDetail(Project emp)
            {
                db.Project.Add(emp);
                db.SaveChanges();

                return emp.Prid;
            }



            public int UpdateDetail(int id, Project emp)
            {
                if (db != null)
                {
                    var obj = (db.Project.Where(x => x.Prid == id)).FirstOrDefault();
                    if (obj != null)
                    {
                        obj.Prname = emp.Prname;
                        obj.Stid = emp.Stid;


                        db.SaveChanges();
                        return 1;
                    }
                    return 0;
                }
                return 0;
            }

            public int Delete(int id)
            {
                int result = 0;

                if (db != null)
                {

                    var post = db.Project.FirstOrDefault(x => x.Prid == id);

                    if (post != null)
                    {

                        db.Project.Remove(post);
                        result = db.SaveChanges();
                        return 1;
                    }
                    return result;
                }

                return result;

            }

           
        }
    
}
