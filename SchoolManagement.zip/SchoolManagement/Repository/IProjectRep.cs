﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagement.Repository
{
    public interface IProjectRep
    {
        public List<Project> GetDetails();
        public Project GetDetail(int id);
        public int AddDetail(Project emp);
        public int UpdateDetail(int id, Project emp);
        public int Delete(int id);
    }
}
