﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagement.Repository
{
    public class StudentRep : IStudentRep
    {
        studentsysContext db;
        public StudentRep(studentsysContext _db)
        {
            db = _db;
        }

        public List<Student> GetDetails()
        {
            return db.Student.ToList();
        }

        public Student GetDetail(int id)
        {
            if (db != null)
            {
                return (db.Student.Where(x => x.Stid == id)).FirstOrDefault();
            }
            return null;
        }

        public int AddDetail(Student emp)
        {
            db.Student.Add(emp);
            db.SaveChanges();

            return emp.Stid;
        }



        public int UpdateDetail(int id, Student emp)
        {
            if (db != null)
            {
                var obj = (db.Student.Where(x => x.Stid == id)).FirstOrDefault();
                if (obj != null)
                {
                    obj.Stname = emp.Stname;
                    obj.Stage = emp.Stage;
                    obj.Stclas = emp.Stclas;
                 
                    db.SaveChanges();
                    return 1;
                }
                return 0;
            }
            return 0;
        }

        public int Delete(int id)
        {
            int result = 0;

            if (db != null)
            {

                var post = db.Student.FirstOrDefault(x => x.Stid == id);

                if (post != null)
                {

                    db.Student.Remove(post);
                    result = db.SaveChanges();
                    return 1;
                }
                return result;
            }

            return result;

        }
    }
}
