﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using SchoolManagement.Controllers;
using SchoolManagement.Models;
using SchoolManagement.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SchoolManagementTest
{
    class ProjectsControllerTest
    {
        studentsysContext db;

        [SetUp]
        public void Setup()
        {
            var emp = new List<Project>
            {
                new Project{Prname="Dummy",Prid=1,Stid=1},
                new Project{Prname="Dummy1",Prid=2,Stid=5},
                new Project{Prname="Dummy3",Prid=3,Stid=8},

            };

            var empdata = emp.AsQueryable();
            var mockSet = new Mock<DbSet<Project>>();
            mockSet.As<IQueryable<Project>>().Setup(m => m.Provider).Returns(empdata.Provider);
            mockSet.As<IQueryable<Project>>().Setup(m => m.Expression).Returns(empdata.Expression);
            mockSet.As<IQueryable<Project>>().Setup(m => m.ElementType).Returns(empdata.ElementType);
            mockSet.As<IQueryable<Project>>().Setup(m => m.GetEnumerator()).Returns(empdata.GetEnumerator());

            var mockContext = new Mock<studentsysContext>();
            mockContext.Setup(c => c.Project).Returns(mockSet.Object);
            db = mockContext.Object;

        }



        [Test]
        public void GetDetailsTest()
        {
            var res = new Mock<ProjectRep>(db);
            ProjectsController obj = new ProjectsController(res.Object);
            var data = obj.Get();
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);

        }

        [Test]
        public void Add_Valid_Detail()
        {
            var res = new Mock<ProjectRep>(db);
            ProjectsController obj = new ProjectsController(res.Object);
            Project emp = new Project { Prname = "Dummy", Prid = 10, Stid = 1 };

            var data = obj.Post(emp);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }





        [Test]
        public void GetDetailTest()
        {
            ProjectRep res = new ProjectRep(db);
            ProjectsController obj = new ProjectsController(res);
            var data = obj.Get1(1);
            var okResult = data as ObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }



        [Test]
        public void Update_Valid_Detail()
        {

            Project emp = new Project { Prname = "Dummy", Prid = 10, Stid = 1 };
            ProjectRep res = new ProjectRep(db);
            ProjectsController obj = new ProjectsController(res);
            var data = obj.Put(1, emp);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }
        [Test]
        public void Delete_Valid_Detail()
        {
            ProjectRep loandata = new ProjectRep(db);
            ProjectsController obj = new ProjectsController(loandata);
            var data = obj.Delete(1);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }
    }
}

