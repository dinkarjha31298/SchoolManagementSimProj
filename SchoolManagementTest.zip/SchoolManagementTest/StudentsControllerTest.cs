﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using SchoolManagement.Controllers;
using SchoolManagement.Models;
using SchoolManagement.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SchoolManagementTest
{
    class StudentsControllerTest
    {
        studentsysContext db;

        [SetUp]
        public void Setup()
        {
            var emp = new List<Student>
            {
                new Student{Stname="Dummy10",Stid=1,Stage=1,Stclas=1},
                new Student{Stname="Dummy11",Stid=2,Stage=2,Stclas=2},
                new Student{Stname="Dummy13",Stid=3,Stage=3,Stclas=3},

            };

            var empdata = emp.AsQueryable();
            var mockSet = new Mock<DbSet<Student>>();
            mockSet.As<IQueryable<Student>>().Setup(m => m.Provider).Returns(empdata.Provider);
            mockSet.As<IQueryable<Student>>().Setup(m => m.Expression).Returns(empdata.Expression);
            mockSet.As<IQueryable<Student>>().Setup(m => m.ElementType).Returns(empdata.ElementType);
            mockSet.As<IQueryable<Student>>().Setup(m => m.GetEnumerator()).Returns(empdata.GetEnumerator());

            var mockContext = new Mock<studentsysContext>();
            mockContext.Setup(c => c.Student).Returns(mockSet.Object);
            db = mockContext.Object;

        }



        [Test]
        public void GetDetailsTest()
        {
            var res = new Mock<StudentRep>(db);
            StudentsController obj = new StudentsController(res.Object);
            var data = obj.Get();
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);

        }

        [Test]
        public void Add_Valid_Detail()
        {
            var res = new Mock<StudentRep>(db);
            StudentsController obj = new StudentsController(res.Object);
            Student emp = new Student { Stname = "Dummy10", Stid = 10, Stage = 1, Stclas = 1 };

            var data = obj.Post(emp);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }





        [Test]
        public void GetDetailTest()
        {
            StudentRep res = new StudentRep(db);
            StudentsController obj = new StudentsController(res);
            var data = obj.Get1(1);
            var okResult = data as ObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }



        [Test]
        public void Update_Valid_Detail()
        {

            Student emp = new Student { Stname = "Dummy10", Stid = 10, Stage = 1, Stclas = 1 };
            StudentRep res = new StudentRep(db);
            StudentsController obj = new StudentsController(res);
            var data = obj.Put(1, emp);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }
        [Test]
        public void Delete_Valid_Detail()
        {
            StudentRep roll = new StudentRep(db);
            StudentsController obj = new StudentsController(roll);
            var data = obj.Delete(1);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }
    }
}
